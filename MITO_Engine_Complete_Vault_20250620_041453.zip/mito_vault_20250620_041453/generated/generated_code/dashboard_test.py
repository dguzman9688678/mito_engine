def dashboard_test():
    return "Working"