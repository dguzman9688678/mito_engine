def pipeline_test():
    return "File save pipeline working"

if __name__ == "__main__":
    print(pipeline_test())